package com.example.mob4aidesafio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputSinal = findViewById<EditText>(R.id.inputSinal)
        val inputLatencia = findViewById<EditText>(R.id.inputLatencia)
        val inputThroughput = findViewById<EditText>(R.id.inputThroughput)
        val inputFrequencia = findViewById<EditText>(R.id.inputFrequencia)
        val inputRSRP = findViewById<EditText>(R.id.inputRSRP)
        val inputRSRQ = findViewById<EditText>(R.id.inputRSRQ)
        val button = findViewById<Button>(R.id.buttonPredict)
        val result = findViewById<TextView>(R.id.textViewResult)

        button.setOnClickListener {
            val sinal = inputSinal.text.toString().toIntOrNull() ?: 0
            val latencia = inputLatencia.text.toString().toIntOrNull() ?: 0
            val throughput = inputThroughput.text.toString().toIntOrNull() ?: 0
            val frequencia = inputFrequencia.text.toString().toIntOrNull() ?: 0
            val rsrp = inputRSRP.text.toString().toIntOrNull() ?: 0
            val rsrq = inputRSRQ.text.toString().toIntOrNull() ?: 0

            val previsao = sinal + (throughput / 2) - latencia + frequencia - rsrp + rsrq

            result.text = "Previsão de consumo: $previsao mAh"
        }
    }
}